/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

import java.util.ArrayList;

/**
 *
 * @author Alex Altuve
 */
public class Secretaria extends Persona {
   
    public Secretaria() {
        super();
      
    }
   
    public Secretaria(String DireccionC, String Cedula, String Nombre, String Telefono, String Correo, String Cargo, String User, String Clave, String Fecha_Ingreso) {
        super(DireccionC, Cedula, Nombre, Telefono, Correo, Cargo, User, Clave, Fecha_Ingreso);
    }
    
    
 
}
